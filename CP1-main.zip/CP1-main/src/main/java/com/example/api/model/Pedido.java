package com.example.api.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Nome do cliente obrigatório")
    private String clienteNome;

    private LocalDate dataPedido;

    @PositiveOrZero(message = "Valor total não pode ser negativo")
    private double valorTotal;

    public Pedido() {
        // Construtor padrão exigido pelo JPA
    }

    public Pedido(String clienteNome, double valorTotal) {
        this.clienteNome = clienteNome;
        this.valorTotal = valorTotal;
    }

    @PrePersist
    public void gerarData() {
        this.dataPedido = LocalDate.now();
    }

    // Getters e Setters

    public Long getId() { return id; }

    public String getClienteNome() { return clienteNome; }
    public void setClienteNome(String clienteNome) { this.clienteNome = clienteNome; }

    public LocalDate getDataPedido() { return dataPedido; }

    public double getValorTotal() { return valorTotal; }
    public void setValorTotal(double valorTotal) { this.valorTotal = valorTotal; }
}
