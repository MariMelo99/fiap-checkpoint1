package com.example.api.config;

import com.example.api.model.Pedido;
import com.example.api.repository.PedidoRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PedidoLoader {

    @Bean
    CommandLineRunner carregarPedidos(PedidoRepository pedidoRepository) {
        return args -> {
            pedidoRepository.deleteAll();

            pedidoRepository.save(new Pedido("Cliente Exemplo 1", 800.00));
            pedidoRepository.save(new Pedido("Cliente Exemplo 2", 1299.99));
        };
    }
}
